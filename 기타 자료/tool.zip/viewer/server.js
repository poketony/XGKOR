const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3000;

app.use(bodyParser.json());
app.use(express.static('public'));

// Configuration: Paths to the directories
const ROOT_DIR = path.resolve(__dirname, '../../');

function getDirs(disc = 'CD1') {
    const d = disc.toUpperCase(); // 'CD1' or 'CD2'
    return {
        JAP: path.join(ROOT_DIR, `${d}JAP`),
        MT: path.join(ROOT_DIR, `${d}MT`),
        KOR: path.join(ROOT_DIR, `${d}KOR`)
    };
}

// Helper to recursively get files
function getFiles(dir, relativePath = '', fileList = []) {
    if (!fs.existsSync(dir)) return fileList;
    
    const files = fs.readdirSync(dir);
    
    files.forEach(file => {
        const fullPath = path.join(dir, file);
        const localPath = path.join(relativePath, file);
        
        if (fs.statSync(fullPath).isDirectory()) {
            getFiles(fullPath, localPath, fileList);
        } else {
            if (file.endsWith('.txt')) {
                fileList.push(localPath);
            }
        }
    });
    return fileList;
}

// API: Get list of files
app.get('/api/files', (req, res) => {
    const disc = req.query.disc || 'CD1';
    const DIRS = getDirs(disc);
    try {
        const files = getFiles(DIRS.JAP);
        res.json(files);
    } catch (error) {
        console.error("Error listing files:", error);
        res.status(500).json({ error: error.message });
    }
});

// API: Get file content from all 3 sources
app.get('/api/content', (req, res) => {
    const filePath = req.query.path; 
    const disc = req.query.disc || 'CD1';
    const DIRS = getDirs(disc);
    
    if (!filePath) {
        return res.status(400).json({ error: "Missing 'path' query parameter" });
    }

    const responseData = {};
    
    ['JAP', 'MT', 'KOR'].forEach(key => {
        const fullPath = path.join(DIRS[key], filePath);
        try {
            if (fs.existsSync(fullPath)) {
                responseData[key] = fs.readFileSync(fullPath, 'utf16le');
            } else {
                responseData[key] = ""; 
            }
        } catch (err) {
            console.error(`Error reading ${key} file:`, err);
            responseData[key] = `Error reading file: ${err.message}`;
        }
    });

    res.json(responseData);
});

// API: Save content to KOR
app.post('/api/save', (req, res) => {
    const { filePath, content, disc } = req.body;
    const DIRS = getDirs(disc || 'CD1');
    
    if (!filePath || content === undefined) {
        return res.status(400).json({ error: "Missing filePath or content" });
    }

    const fullPath = path.join(DIRS.KOR, filePath);
    
    try {
        // Ensure directory exists
        const dir = path.dirname(fullPath);
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }
        
        // Normalize line endings to CRLF (0D 00 0A 00) before saving
        // Browser textareas normalize everything to LF (\n), so we restore \r\n
        const normalizedContent = content.replace(/\r?\n/g, '\r\n');

        // Write back as UTF-16LE
        fs.writeFileSync(fullPath, normalizedContent, 'utf16le');
        res.json({ success: true });
    } catch (err) {
        console.error("Error saving file:", err);
        res.status(500).json({ error: err.message });
    }
});

app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
    console.log(`Root Dir: ${ROOT_DIR}`);
});
