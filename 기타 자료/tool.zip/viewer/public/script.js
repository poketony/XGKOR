document.addEventListener('DOMContentLoaded', () => {
    const fileListEl = document.getElementById('fileList');
    const searchInput = document.getElementById('fileSearch');
    const editorJap = document.getElementById('editor-jap');
    const editorMt = document.getElementById('editor-mt');
    const editorKor = document.getElementById('editor-kor');
    const saveBtn = document.getElementById('saveBtn');
    const statusMsg = document.getElementById('statusMsg');
    
    const discSelect = document.getElementById('discSelect');
    const viewListBtn = document.getElementById('viewListBtn');
    const viewTreeBtn = document.getElementById('viewTreeBtn');

    let currentFilePath = null;
    let allFiles = [];
    let currentView = 'tree'; // 'list' or 'tree'
    let currentDisc = localStorage.getItem('currentDisc') || 'CD1';

    // Set initial value
    discSelect.value = currentDisc;

    // --- Data Fetching ---
    function fetchFiles() {
        statusMsg.textContent = 'Fetching files...';
        fetch(`/api/files?disc=${currentDisc}`)
            .then(res => res.json())
            .then(files => {
                allFiles = files;
                render();
                statusMsg.textContent = `Found ${files.length} files.`;
            })
            .catch(err => {
                console.error('Error fetching files:', err);
                statusMsg.textContent = 'Error fetching files.';
            });
    }

    fetchFiles();

    discSelect.addEventListener('change', () => {
        currentDisc = discSelect.value;
        localStorage.setItem('currentDisc', currentDisc);
        currentFilePath = null;
        fetchFiles();
        editorJap.value = '';
        editorMt.value = '';
        editorKor.value = '';
    });

    // --- View Handling ---
    viewListBtn.addEventListener('click', () => {
        if (currentView === 'list') return;
        currentView = 'list';
        viewListBtn.classList.add('active');
        viewTreeBtn.classList.remove('active');
        render();
    });

    viewTreeBtn.addEventListener('click', () => {
        if (currentView === 'tree') return;
        currentView = 'tree';
        viewTreeBtn.classList.add('active');
        viewListBtn.classList.remove('active');
        render();
    });

    searchInput.addEventListener('input', () => {
        // If searching, force list view mostly, or just filter list. 
        // For simplicity, search affects both, but Tree view search is harder.
        // Let's keep search simple: If text exists, switch to List view or filter list.
        // If user is in Tree view and types, let's filter the List view for easier result finding?
        // Or implement a filtered tree. For now, let's just filter.
        render();
    });

    function render() {
        const searchTerm = searchInput.value.toLowerCase();
        const filteredFiles = allFiles.filter(f => f.toLowerCase().includes(searchTerm));

        fileListEl.innerHTML = '';

        if (currentView === 'list' || searchTerm.length > 0) {
            // Force list view if searching (easier UX than filtering tree)
            renderListView(filteredFiles);
        } else {
            renderTreeView(filteredFiles);
        }
    }

    // --- List View Implementation ---
    function renderListView(files) {
        files.forEach(file => {
            const li = document.createElement('li');
            li.textContent = file;
            li.className = 'file-item';
            if (file === currentFilePath) li.classList.add('active');
            
            li.onclick = () => loadFile(file, li);
            fileListEl.appendChild(li);
        });
    }

    // --- Tree View Implementation ---
    function renderTreeView(files) {
        // Build Tree Structure
        const treeRoot = {};
        
        files.forEach(path => {
            const parts = path.split(/[/\\]/); // Split by / or \
            let currentLevel = treeRoot;
            
            parts.forEach((part, index) => {
                if (!currentLevel[part]) {
                    currentLevel[part] = index === parts.length - 1 ? '__FILE__' : {};
                }
                currentLevel = currentLevel[part];
            });
        });

        // Recursive render
        function createTreeDom(node, fullPath = '') {
            const ul = document.createElement('ul');
            ul.className = fullPath ? 'tree-group' : 'tree-root';

            // Sort: Directories first, then files
            const keys = Object.keys(node).sort((a, b) => {
                const aIsFile = node[a] === '__FILE__';
                const bIsFile = node[b] === '__FILE__';
                if (aIsFile === bIsFile) return a.localeCompare(b);
                return aIsFile ? 1 : -1;
            });

            keys.forEach(key => {
                const isFile = node[key] === '__FILE__';
                const itemPath = fullPath ? `${fullPath}/${key}` : key;
                
                const li = document.createElement('li');
                li.className = 'tree-node';

                const label = document.createElement('div');
                label.className = `tree-label ${isFile ? 'tree-file' : 'tree-folder'}`;
                
                // Icon / Expander
                const icon = document.createElement('span');
                icon.className = 'tree-icon';
                icon.textContent = isFile ? '📄' : '📁';
                label.appendChild(icon);

                // Text
                const text = document.createElement('span');
                text.textContent = key;
                label.appendChild(text);

                li.appendChild(label);

                if (isFile) {
                    label.onclick = () => loadFile(itemPath, label);
                    if (itemPath === currentFilePath) label.classList.add('active');
                } else {
                    // Folder Click: Toggle
                    label.onclick = () => {
                        const childUl = li.querySelector('ul');
                        if (childUl) {
                            const isExpanded = childUl.classList.toggle('expanded');
                            icon.textContent = isExpanded ? '📂' : '📁';
                        }
                    };
                    
                    // Recursive call for children
                    const childrenUl = createTreeDom(node[key], itemPath);
                    li.appendChild(childrenUl);
                }

                ul.appendChild(li);
            });
            return ul;
        }

        const domTree = createTreeDom(treeRoot);
        fileListEl.appendChild(domTree);
    }

    // --- File Loading Logic ---
    function loadFile(filePath, listItem) {
        // Update active class UI
        document.querySelectorAll('.active').forEach(el => {
             // Only remove from list items/labels, not view buttons
             if(el.classList.contains('file-item') || el.classList.contains('tree-label')) {
                 el.classList.remove('active');
             }
        });
        if (listItem) listItem.classList.add('active');

        currentFilePath = filePath;
        statusMsg.textContent = 'Loading...';

        fetch(`/api/content?path=${encodeURIComponent(filePath)}&disc=${currentDisc}`)
            .then(res => res.json())
            .then(data => {
                editorJap.value = data.JAP || '';
                editorMt.value = data.MT || '';
                editorKor.value = data.KOR || '';
                statusMsg.textContent = `Loaded: ${filePath}`;
            })
            .catch(err => {
                console.error('Error loading content:', err);
                statusMsg.textContent = 'Error loading file.';
            });
    }

    // --- Synchronized Scrolling ---
    const textareas = [editorJap, editorMt, editorKor];
    textareas.forEach(ta => {
        ta.addEventListener('scroll', (e) => {
            const scrollTop = e.target.scrollTop;
            textareas.forEach(other => {
                if (other !== e.target) {
                    other.scrollTop = scrollTop;
                }
            });
        });
    });

    // --- Save Logic ---
    function saveFile() {
        if (!currentFilePath) return;

        statusMsg.textContent = 'Saving...';
        
        fetch('/api/save', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                filePath: currentFilePath,
                content: editorKor.value,
                disc: currentDisc
            })
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                statusMsg.textContent = 'Saved successfully!';
                setTimeout(() => statusMsg.textContent = `Loaded: ${currentFilePath}`, 2000);
            } else {
                statusMsg.textContent = 'Save failed: ' + data.error;
            }
        })
        .catch(err => {
            console.error('Error saving:', err);
            statusMsg.textContent = 'Error saving file.';
        });
    }

    saveBtn.addEventListener('click', saveFile);

    // Ctrl+S shortcut
    document.addEventListener('keydown', (e) => {
        if ((e.ctrlKey || e.metaKey) && e.key === 's') {
            e.preventDefault();
            saveFile();
        }
    });
});